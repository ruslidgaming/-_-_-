from flask import Flask
from flask import render_template

app = Flask(__name__)
prof = input()


@app.route('/')
@app.route('/index')
def index():
    return render_template('base.html', title='Заготовка')


@app.route(f'/training/{prof}')
def training():
    return render_template('index.html', prof=prof)


if __name__ == '__main__':
    app.run(port=8080, host='127.0.0.1')